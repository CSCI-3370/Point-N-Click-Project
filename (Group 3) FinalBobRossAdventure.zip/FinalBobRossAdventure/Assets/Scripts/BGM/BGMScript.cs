﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGMScript : MonoBehaviour {

    private AudioSource bgm;

	// Use this for initialization
	void Start () {
        bgm = GetComponent<AudioSource>();
        bgm.Play();
	}
}