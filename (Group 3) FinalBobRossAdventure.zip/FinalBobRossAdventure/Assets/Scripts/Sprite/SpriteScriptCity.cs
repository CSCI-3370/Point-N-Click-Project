﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteScriptCity : MonoBehaviour {

    public Transform target; //Agent's Transform
    public float zOffset;

    void LateUpdate() {
        //Target = Agent
        //Transform = Sprite
        transform.localPosition = new Vector3(target.localPosition.x, transform.localPosition.y, target.localPosition.z + zOffset);
    }
}
