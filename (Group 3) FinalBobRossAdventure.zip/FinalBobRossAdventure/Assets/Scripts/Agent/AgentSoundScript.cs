﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentSoundScript : MonoBehaviour {

    private AudioSource letsgetcrazy;
    public Transform target;
    public float zOffset;

    // Use this for initialization
    void Start () {
        letsgetcrazy = GetComponent<AudioSource>();
        letsgetcrazy.Play();	
	}

    void Update() {
        transform.localPosition = new Vector3(target.localPosition.x, transform.localPosition.y,target.localPosition.z + zOffset);
    }
}
