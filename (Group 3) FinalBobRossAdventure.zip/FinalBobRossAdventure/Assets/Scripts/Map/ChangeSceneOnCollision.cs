﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeSceneOnCollision : MonoBehaviour {

    void OnCollisionEnter(Collision collision) {
        if (collision.gameObject.name == "DoorToCity") {
            SceneManager.LoadScene(0);
        } else if (collision.gameObject.name == "DoorToDirt") {
            SceneManager.LoadScene(1);
        } else if (collision.gameObject.name == "DoorToStore") {
            SceneManager.LoadScene(2);
        } else if (collision.gameObject.name == "DoorToInn") {
            SceneManager.LoadScene(3);
        }
    }
}